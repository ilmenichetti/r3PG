# replace some
prepare_sizeDist( size_dist = d_sizeDist[1:4,],
  sp_names = c('Fagus sylvatica', 'Pinus sylvestris' ))

# Make default
prepare_sizeDist( size_dist = NULL, sp_names = c('Quercus', 'Abies'))

