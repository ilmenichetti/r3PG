prepare_input( site = d_site, species = d_species, climate = d_climate, d_thinning)
