# replace some
prepare_parameters( parameters = d_parameters[1:4,],
  sp_names = c('Fagus sylvatica', 'Pinus sylvestris' ))

# Make default
prepare_parameters( parameters = NULL, sp_names = c('Quercus', 'Abies'))

