prepare_thinning( thinning = NULL, sp_names = c('Quercus', 'Abies'))

prepare_thinning( thinning = d_thinning, sp_names = c('Fagus sylvatica', 'Pinus sylvestris'))
